# IBM Bob 2.0 Hackathon — Onboarding Pack PoC

Status: **v2 built (skill, scripts, PDF kit); not yet run in Bob.**


## Structure

- **[Research/](Research/)** — everything backing the design decisions: hackathon rules, the onboarding-effectiveness literature (papers + industry articles, international → SEA → Malaysia), the solutions-mapping across 5 patterns, and the LACY deep dive that anchors the whole approach.
- **[Development/](Development/)** — the build. v2 pipeline: `/onboard` skill (`.bob/skills/onboarding-pipeline`), helper scripts (timeline, checks, install-deps, PDF via a pycairo brochure kit, optional narrated tour video via Piper + ffmpeg), and `requirements/` capturing the v2 asks. Not yet run through Bob: no `bob_sessions/` screenshots, email MCP server not built.

## Next step
Open `Development/` in Bob IDE and work through `Development/BOB_PROMPTS.md` in order, then `/onboard`.

## Note on Research/
These are the working notes behind the design decisions, bundled so the repo is self-contained.
